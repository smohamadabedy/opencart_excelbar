<?php 
$_['heading_title']    = 'Excelbar module';

$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified Excelbar module!';
$_['text_edit']        = 'Edit Excelbar Module';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Excelbar module!';